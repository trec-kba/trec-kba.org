TREC KBA 2014 Truth Data
========================

Release Date:  2014-10-15

This tar archive includes:

 1) trec-kba-2014-10-15-ccr-and-ssf.profiles.yaml  
    is the primary truth data.

 2) construct_time_progression_per_entity.py 
    is a script for analyzing the time series for each entity, which
    selects the end of the Training Time Range (TTR) for each entity
    and generates the *-query-topics.json and -vital-histogram.tsv

 3) convert_to_tsv.py 
    is a script that uses the TTR end times recorded in
    *-query-topics.json to convert the primary truth data into the
    standard tab-separated value format for training and evaluation.

 4) trec-kba-2014-10-15-ccr-and-ssf.before-cutoff.tsv 
    is the training data that Vital Filtering systems can use as both
    the definition of the entities and as training data.

 5) trec-kba-2014-10-15-ccr-and-ssf.after-cutoff.tsv 
    is the evaluation data that must not be accessed by systems when
    generating "automatic" runs.

 6) trec-kba-2014-assessor-guidelines.pdf 
    is the annotation guidelines.

 7) trec-kba-2014-10-15-vital-rating-interassessor-agreements.txt
    shows interassessor agreement data per entity.

 8) trec-kba-2014-10-15-ccr-and-ssf.slot_names.json 
    is the list of slot names for each entity type.

Note that the TTR end time is *different* for each entity, because we
want to ensure that there are enough vitals in the training data for
each entity.  The threshold is 20%, i.e. at least 20% of the vitals
are included in or before the cutoff for each entity.  Some entities
have "null" as the training_time_range_end, which means that they are
*not* query targets for Vital Filtering (aka CCR).  These are included
because they may be good query targets for SSF.


Here are two examples.  

        {
            "canonical_name": "Missing Women Commission of Inquiry", 
            "entity_type": "ORG", 
            "external_profile": [
                "http://www.missingwomeninquiry.ca/"
            ], 
            "target_id": "https://kb.diffeo.com/Missing_Women_Commission_of_Inquiry", 
            "training_time_range_end": "2011-11-30-01"
        }, 
        {
            "canonical_name": "A. J. Rathbun", 
            "entity_type": "PER", 
            "external_profile": [
                "http://www.seattlemag.com/profiles/aj-rathbun", 
                "http://www.ajrathbun.com/"
            ], 
            "target_id": "https://kb.diffeo.com/A._J._Rathbun", 
            "training_time_range_end": null
        }, 


The first is an organization with 35 of its 174 vital documents
appearing on or before 2011-11-30-01.  As with all of the KBA 2014
query entities, this entity is *defined* by the documents the refer to
it (rating=1 or rating=2) before the training_time_range_end and also
by its home page, which is provided as a URL in the external_profile.
A CCR system may only use the URLs in external_profile, if it can
ensure that it obeys the "no future info" rule by accessing only
versions of the content from before each date hour being processed.
This rule is straightforward to obey for the 27 entities with
Wikipedia URLs, and may also possible to obey using tools like the
WayBack Machine http://archive.org/help/wayback_api.php

This second example is a person entity that did not have enough vitals
to be used as a query target in Vital Filtering (CCR).  However, his
profile contains many slot fills, so he is a good SSF query.  For SSF,
this entity is defined by *all* of the truth data that mentions him,
and also the external profiles.  It is valid for an SSF system to use
all of the truth data from before and after the cutoff and also
external profiles.  (If we find that this is sufficient to make SSF
"easy," then there will be much rejoicing and we will make it harder
next year :-)

The *goal* of an SSF system is to select strings from the corpus and
associate them with an entity and a slot name.  Note that the slot
names are defined by the TAC KBP slot filling guidelines (linked
below), except for *_CONTACT and *_EMAIL, which contain communication
information such as phone numbers, postal addresses, and email
addresses of organizations ane people.

https://github.com/trec-kba/streamcorpus/blob/master/if/TAC_2013_KBP_Slot_Descriptions_1.0.pdf?raw=true

The experimental SSF scorer is in
https://github.com/trec-kba/kba-scorer/blob/master/src/kba/scorer2/ssf.py
and results will be circulated directly to teams that participated in
SSF.


Details
-------

Steps for generating the files above using the two scripts:

	python construct_time_progression_per_entity.py  trec-kba-2014-10-15-ccr-and-ssf.profiles.yaml trec-kba-2014-10-15-vital-histogram.tsv  trec-kba-2014-10-15-ccr-and-ssf-query-topics.json

	python convert_to_tsv.py  trec-kba-2014-10-15-ccr-and-ssf.profiles.yaml  trec-kba-2014-10-15-ccr-and-ssf-query-topics.json  trec-kba-2014-10-15-ccr-and-ssf
