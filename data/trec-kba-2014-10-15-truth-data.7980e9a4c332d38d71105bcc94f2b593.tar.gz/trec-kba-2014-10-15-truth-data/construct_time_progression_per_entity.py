'''generates counts per entity per date_hour, and also generates the
filter-topics.json with 20% of the truth data's vitals in each
entity's TTR

.. This software is released under an MIT/X11 open source license.
   Copyright 2012-2014 Diffeo, Inc.

'''
from __future__ import division, print_function

from streamcorpus import make_stream_time
def get_epoch_ticks_for_date_hour(date_hour):
    '''
    Returns an epoch_ticks int for the start of a date_hour string
    '''
    parts = date_hour.split('-')
    assert len(parts) == 4
    zt = '-'.join(parts[:3]) + 'T' + parts[3] + ':00:00.000000Z'
    return make_stream_time(zt).epoch_ticks

import argparse
import sys
from operator import itemgetter, attrgetter
from collections import Counter, defaultdict
import yaml
import json
from convert_to_tsv import get_stream_id_and_offsets

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('input_profiles')
    parser.add_argument('output_histogram')
    parser.add_argument('output_filter_topics')
    args = parser.parse_args()
    assert args.output_histogram.endswith('.tsv')
    assert args.output_filter_topics.endswith('.json')
    out_fh = open(args.output_histogram, 'wb')
    profiles = yaml.load(open(args.input_profiles))

    date_hours_vitals = defaultdict(Counter)
    date_hours_ratings = defaultdict(Counter)
    labels = set()
    num_citations = 0
    num_vitals = 0
    num_ratings = 0
    total_ratings = Counter()
    total_vitals = Counter()

    for label, entity in profiles['entities'].items():
        for citation in entity['citations']:
            num_citations += 1

            rating = citation['relevance']
            assert rating in set([-1,0,1,2])

            stream_id, offsets = get_stream_id_and_offsets(citation['mention_id'])
            date_hour = make_stream_time(epoch_ticks=int(stream_id.split('-')[0])).zulu_timestamp[:13].replace('T', '-')

            labels.add(label)

            date_hours_ratings[date_hour][label] += 1

            total_ratings[label] += 1
            num_ratings += 1
            if rating == 2:
                date_hours_vitals[date_hour][label] += 1
                total_vitals[label] += 1
                num_vitals += 1

    labels = list(labels)
    labels.sort()

    sys.stderr.write('%d %d\n' % (num_citations, num_vitals))

    ## build a list of all date_hours in the full range, even if there are
    ## no vitals or even ratings in a given hour
    date_hours_str = date_hours_vitals.keys()
    date_hours_str.sort()
    first = get_epoch_ticks_for_date_hour(min(date_hours_vitals))
    last  = get_epoch_ticks_for_date_hour(max(date_hours_vitals))
    epoch_ticks = [first]
    while epoch_ticks[-1] <= last + 3600:
        epoch_ticks.append(epoch_ticks[-1] + 3600)
    date_hours_str = []
    for et in epoch_ticks:
        zulu = make_stream_time(epoch_ticks=et).zulu_timestamp
        date_hours_str.append(zulu[:13].replace('T', '-'))

    ## build a histogram for loading in Excel, and also capture the hour
    ## at which 20% of the vitals have appeared.  Use 20% as the magic
    ## amount of training data provided, and therefore the definition of
    ## the TTR.
    earliests = dict()
    before = Counter()
    after = Counter()
    disincluded = Counter()
    fifth = dict()
    vitals_per_month = defaultdict(Counter)

    for label in labels:
        if label not in total_vitals:
            print('entity without vitals: %s' % label)


    print('\t'.join(['date_hour'] + labels), file=out_fh)
    for dh in date_hours_str:
        print('\n'.join(['\t'.join([dh] + [str(date_hours_vitals[dh][label]) for label in labels])]), file=out_fh)

        for label in labels:

            ## crucial: if 20% of the vitals would be fewer than one, drop
            ## entity from CCR, can still use in SSF.
            if total_vitals[label] < 5:
                if label not in disincluded:
                    disincluded[label] = total_vitals[label]
                continue

            if date_hours_vitals[dh][label] > 0:
                if label not in earliests:
                    earliests[label] = dh
                    sys.stderr.write('%d\t%s\n' % (total_vitals[label], label))

                if label not in fifth:
                    before[label] += date_hours_vitals[dh][label]
                    fraction = before[label] / total_vitals[label]
                    if fraction >= 0.2:
                        sys.stderr.write('%d of %d vitals happen before %s for %s\n' % (before[label], total_vitals[label], dh, label))
                        fifth[label] = dh
                else:
                    after[label] += date_hours_vitals[dh][label]

                vitals_per_month[label][dh[:7]] += date_hours_vitals[dh][label]

    assert sum(before.values()) + sum(after.values()) + sum(disincluded.values()) == sum(total_vitals.values()), \
        (sum(before.values()), sum(after.values()), sum(disincluded.values()), sum(total_vitals.values()))
    assert sum(disincluded.values()) < 23 * 4  ## 23 have between one and four vitals
    assert len(disincluded) == 35, (len(disincluded), disincluded)  ## 15 more have zero vitals
    assert len(before) == 74, len(before) ## number of actual query targets
    ratio = sum(before.values()) / sum(total_vitals.values())
    assert abs(ratio - 0.2) < 0.04, ratio
    ratio = sum(after.values()) / sum(total_vitals.values())
    assert abs(ratio - 0.8) < 0.04, ratio

    for label in before:
        ratio = before[label] / total_vitals[label]
        if abs(ratio - 0.2) > 0.06:
            sys.stderr.write('%d of %d vitals before the cutoff: %r for %s\n' % (before[label], total_vitals[label], vitals_per_month[label], label))

    print('%d entities with enough vitals to be query targets' % len(fifth))

    print('date_hour\tlabel\ttotal_vitals', file=out_fh)
    fifth_list = fifth.items()
    fifth_list.sort(key=itemgetter(1))
    for label, dh in fifth_list:
        print('\t'.join(map(str, [dh, label, total_vitals[label]])), file=out_fh)

    profiles = yaml.load(open('trec-kba-2014-07-11-ccr-and-ssf.profiles.yaml'))

    filter_topics = {
        "$schema": "http://trec-kba.org/schemas/v1.1/filter-topics.json", 
        "targets": [],
        }

    for label in labels:
        ## dh is None if there are no vitals, meaning that it is *not* a CCR query
        dh = fifth.get(label)    
        filter_topics['targets'].append(
            {
                "training_time_range_end": dh,
                "entity_type": profiles['entities'][label]['slots']['entity_type'],
                "target_id": label,
                "external_profile": map(itemgetter('value'), profiles['entities'][label]['slots'].get('external_profile', [])),
                "canonical_name": profiles['entities'][label]['slots']['canonical_name'],

                ## this is useful for diagnostics, but is *not* data that
                ## can be used by automatic systems performing CCR or SSF
                #"vitals_per_month": sorted(vitals_per_month[label].items()),
            }
            )

    filter_topics['targets'].sort(key=itemgetter('training_time_range_end'), reverse=True)

    fh = open(args.output_filter_topics, 'wb')
    fh.write(json.dumps(filter_topics, indent=4, sort_keys=True))
    fh.close()

if __name__ == '__main__':
    main()
