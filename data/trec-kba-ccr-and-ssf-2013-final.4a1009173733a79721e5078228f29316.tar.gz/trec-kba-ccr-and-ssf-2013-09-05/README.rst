KBA 2013
========

The list of KBA 2013 entities and target slots to fill is enclosed in
this tarball.  The format is:
http://trec-kba.org/schemas/v1.1/filter-topics.json

KBA 2013 has two tasks: 
  1) Cumulative Citation Recommendation (CCR), and
  2) Streaming Slot Filling (SSF)

CCR is a document filtering task, and SSF is a slot filling task.

In studying CCR, many people realized that a large fraction of "vital"
documents can be explained with a sentence of the form:

     "The entity's _____ attribute acquired this value: ____."


In fact, it is an interesting research question to identify vital
documents that do not fit this pattern.  These changing entity
profiles reflect real-world events, which often appear as spikes in
this time series plot of all of the vital documents across the entire
seventeen-month time range, which depicts both training and evaluation
ground truth data:

    trec-kba-ccr-2013-vital-doc-counts-per-entity-per-hour.pdf


The underlying corpus time series is plotted here:

    kba-streamcorpus-2013-v0_2_0-source-counts-per-hour.pdf


The CCR task requires coreference resolution of entity mentions.  The
SSF task requires coreference resolution of both entities and slot
fills.  See assessor guidelines for details.

One of KBA's goals is to attract researchers from both information
retrieval and natural language understanding.  CCR naturally caters to
IR, and SSF to NLU.  By weaving the two together, we hope to foster
cross-polination.


Entities for both CCR and SSF
-----------------------------

Entities come from both Wikipedia and Twitter.

Since Twitter does not offer a name-expansion API, it is acceptable to
manually examine the twitter profile page to identify alternate names
for these entities.  This is still considered "run_type": "automatic",
because a human entering this entity as a query could easily be asked
to examine the twitter profile page (and no other texts).

The training time range (TTR) runs through the end of February 2012.

Some entities have no vital examples in the TTR.
For example, some entities only appear in the corpus when they die in
the second half of 2012. 

You will notice that the proportion of judged documents increases
signficantly some time after the TTR, and yet, the number of vitals
does not.  This is because the spinn3r portion of the corpus has more
re-visits to certain URLs, so we enabled the assessors to assign
ratings to these pages in bulk.  We also filtered out many of these
re-visits.

To optimize assessor resources in the first assessment period (March
2013), we did not judge every document for four of the larger new
entities not any of the entities from KBA 2012.  If time permits
during the June/July assessor window, we will conduct more vital
judging on pooled assertions from run submissions for all entities.


Streaming Slot Filling
----------------------

Each entity is one of these three types:

    Facility (FAC)
    Person (PER)
    Organization (ORG)


The entity_type determines the target slots to fill:

type PER: Affiliate, AssociateOf, Contact_Meet_PlaceTime, AwardsWon, DateOfDeath, CauseOfDeath, Titles, FounderOf, EmployeeOf, SignificantOther (optional), Children (optional)

type FAC: Affiliate, Contact_Meet_Entity

type ORG: Affiliate, TopMembers, FoundedBy


Four of these slots require special explanation (below).  The other
values are directly from TAC-KBP or ACE definitions:

http://www.nist.gov/tac/2012/KBP/task_guidelines/TAC_KBP_Slots_V2.4.pdf

http://projects.ldc.upenn.edu/ace/docs/English-Events-Guidelines_v5.4.3.pdf

Since this is *streaming* slot filling, we are only interested in new
slot values that were not substantiated earlier in the streamcorpus,
which ranges from October 2011 to February 2013.  In examining the
Vital-rated documents identified by assessors, we observed that many
of the interesting events in the lives of these people and
organizations, did not easily fit existing slots in KBP or ACE.
Rather than invent specific new slots, we propose these four
generalized slots classes: Affiliate, AssociateOf,
Contact_Meet_Entity, Contact_Meet_PlaceTime.  See details in the
enclosed text file trec-kba-ssf-2013-assessor-guidelines.txt


Output Format
-------------

We have added an optional component to the run submission format
described here:

http://trec-kba.org/trec-kba-2013.shtml

Specfically:

ninth column: slot name adapted from the TAC KBP or ACE slot ontology.  Used in
SSF. Runs for CCR should use 'NULL' in this field. This field most
have a string from the list below. Optionally, this field may contain
a second string separated from the first by a colon ":", where the
second string is a system-selected name for a sub-type or variant of
the target slot. This will not be used in scoring and is provided
solely for the purpose of allowing systems to output more information
about the algorithm's perspective on the slot. This field must not
contain any spaces.

Comments in Run Submission Files
--------------------------------

Comment lines that begin with "#" are permitted throughout the run
submission file, not just at the beginning and end.  Blank lines are
also allowed.  We recommend making your run submission files human
readable by printing out portions of the text that led to each
assertion.


Validating Runs
---------------

All SSF assertions must have a rating of 2, meaning vital.

Confidence scores must be integer between 1 and 1000.

The run submission validator script is here:

  http://trec.nist.gov/act_part/scripts/13.scripts/check_kba.pl


StreamItem.stream_id and epoch_ticks
------------------------------------

Approximately 25% of the total 1bn documents have
StreamItem.stream_time.epoch_ticks that are off by an hour from the
correct GMT value.  This bug was compounded by the fact that the tasks
for assessors were generated before the corpus was complete, and some
of the judged documents were part of websites for which the stream had
many revisits within a very short time frame.  To reduce the content
duplication in the corpus, we filtered many of these duplicates, thus
making it challenging to use the stream_id to find about 10% of the
truth documents provided for CCR.  The updated truth file called
trec-kba-ccr-judgments-2013-07-08.before-cutoff.filter-run.txt has
only stream_id strings that are easily found in the index from
chunk_paths to stream_ids:

http://s3.amazonaws.com/aws-publicdatasets/trec/kba/kba-streamcorpus-2013-v0_2_0-chunk-path-to-stream-id-time.txt.xz

All but one of the training examples provided previously are available
in this updated truth file.  That one was lost through a line wrapping
error, and will probably recovered in a 2014 corpus update.  The
updated file actually has *more* training examples, however these are
duplicate documents of existing training examples.

The enclosed chunk-to-stream-id-and-sizes file contains excerpts from
the index file linked above, so it is easy to find the truth
documents.  This file also contains the length of the raw, clean_html,
and clean_visible content fields.  Not all judged documents have
clean_visible, however only documents with clean_visible will be used
in official scoring:

trec-kba-ccr-judgments-2013-07-08.before-cutoff.chunk-to-stream_id-and-sizes.txt


Deprecated Entities
-------------------

While they can be included in runs, and we are interested in studying
them, the following entities will not be used in official scoring of
KBA SSF 2013 because they were misclassified.  They will be used in
KBA CCR 2013:

 http://en.wikipedia.org/wiki/Fargo_Moorhead_Derby_Girls
 


The following entities will not be used in official scoring of either
KBA SSF or CCR for 2013, because there is insufficient annotation data
on these "large" entities that we attempted to re-use from KBA 2012:

 http://en.wikipedia.org/wiki/Basic_Element_(company)
 http://en.wikipedia.org/wiki/Basic_Element_(music_group)
 http://en.wikipedia.org/wiki/Lovebug_Starski
 http://en.wikipedia.org/wiki/Aharon_Barak
 http://en.wikipedia.org/wiki/Alex_Kapranos
 http://en.wikipedia.org/wiki/Alexander_McCall_Smith
 http://en.wikipedia.org/wiki/Annie_Laurie_Gaylor
 http://en.wikipedia.org/wiki/Bill_Coen
 http://en.wikipedia.org/wiki/Boris_Berezovsky_(businessman)
 http://en.wikipedia.org/wiki/Boris_Berezovsky_(pianist)
 http://en.wikipedia.org/wiki/Charlie_Savage
 http://en.wikipedia.org/wiki/Darren_Rowse
 http://en.wikipedia.org/wiki/Douglas_Carswell
 http://en.wikipedia.org/wiki/Frederick_M._Lawrence
 http://en.wikipedia.org/wiki/Ikuhisa_Minowa
 http://en.wikipedia.org/wiki/James_McCartney
 http://en.wikipedia.org/wiki/Jim_Steyer
 http://en.wikipedia.org/wiki/Lisa_Bloom
 http://en.wikipedia.org/wiki/Mario_Garnero
 http://en.wikipedia.org/wiki/Masaru_Emoto
 http://en.wikipedia.org/wiki/Nassim_Nicholas_Taleb
 http://en.wikipedia.org/wiki/Rodrigo_Pimentel
 http://en.wikipedia.org/wiki/Roustam_Tariko
 http://en.wikipedia.org/wiki/Ruth_Rendell
 http://en.wikipedia.org/wiki/Satoshi_Ishii
 http://en.wikipedia.org/wiki/Vladimir_Potanin
 http://en.wikipedia.org/wiki/William_Cohen
 http://en.wikipedia.org/wiki/William_D._Cohan
 http://en.wikipedia.org/wiki/William_H._Gates,_Sr

